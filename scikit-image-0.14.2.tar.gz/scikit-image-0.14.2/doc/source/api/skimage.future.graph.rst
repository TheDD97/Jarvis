.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`future.graph`
===========================
.. automodule:: skimage.future.graph

.. currentmodule:: skimage.future.graph
.. autosummary::

   skimage.future.graph.rag_mean_color
   skimage.future.graph.cut_threshold
   skimage.future.graph.cut_normalized
   skimage.future.graph.ncut
   skimage.future.graph.show_rag
   skimage.future.graph.merge_hierarchical
   skimage.future.graph.rag_boundary

   skimage.future.graph.RAG


rag_mean_color
--------------

.. autofunction:: skimage.future.graph.rag_mean_color

cut_threshold
-------------

.. autofunction:: skimage.future.graph.cut_threshold

cut_normalized
--------------

.. autofunction:: skimage.future.graph.cut_normalized

ncut
----

.. autofunction:: skimage.future.graph.ncut

show_rag
--------

.. autofunction:: skimage.future.graph.show_rag

merge_hierarchical
------------------

.. autofunction:: skimage.future.graph.merge_hierarchical

rag_boundary
------------

.. autofunction:: skimage.future.graph.rag_boundary


:class:`RAG`
------------


.. autoclass:: RAG
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__
