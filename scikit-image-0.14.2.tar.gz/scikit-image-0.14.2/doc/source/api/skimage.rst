.. AUTO-GENERATED FILE -- DO NOT EDIT!

:mod:`skimage`
==============
.. automodule:: skimage

.. currentmodule:: skimage
.. autosummary::

   skimage.dtype_limits
   skimage.img_as_bool
   skimage.img_as_float
   skimage.img_as_float32
   skimage.img_as_float64
   skimage.img_as_int
   skimage.img_as_ubyte
   skimage.img_as_uint
   skimage.lookfor
   skimage.test


    skimage.color
    skimage.data
    skimage.draw
    skimage.exposure
    skimage.external
    skimage.filters
    skimage.io
    skimage.measure
    skimage.restoration
    skimage.transform
    skimage.util

dtype_limits
------------

.. autofunction:: skimage.dtype_limits

img_as_bool
-----------

.. autofunction:: skimage.img_as_bool

img_as_float
------------

.. autofunction:: skimage.img_as_float

img_as_float32
--------------

.. autofunction:: skimage.img_as_float32

img_as_float64
--------------

.. autofunction:: skimage.img_as_float64

img_as_int
----------

.. autofunction:: skimage.img_as_int

img_as_ubyte
------------

.. autofunction:: skimage.img_as_ubyte

img_as_uint
-----------

.. autofunction:: skimage.img_as_uint

lookfor
-------

.. autofunction:: skimage.lookfor

test
----

.. autofunction:: skimage.test

