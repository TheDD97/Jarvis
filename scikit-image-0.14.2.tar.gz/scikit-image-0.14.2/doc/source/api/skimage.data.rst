.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`data`
===================
.. automodule:: skimage.data

.. currentmodule:: skimage.data
.. autosummary::

   skimage.data.load
   skimage.data.astronaut
   skimage.data.binary_blobs
   skimage.data.camera
   skimage.data.checkerboard
   skimage.data.chelsea
   skimage.data.clock
   skimage.data.coffee
   skimage.data.coins
   skimage.data.horse
   skimage.data.hubble_deep_field
   skimage.data.immunohistochemistry
   skimage.data.lfw_subset
   skimage.data.logo
   skimage.data.moon
   skimage.data.page
   skimage.data.text
   skimage.data.rocket
   skimage.data.stereo_motorcycle



load
----

.. autofunction:: skimage.data.load

astronaut
---------

.. autofunction:: skimage.data.astronaut

binary_blobs
------------

.. autofunction:: skimage.data.binary_blobs

camera
------

.. autofunction:: skimage.data.camera

checkerboard
------------

.. autofunction:: skimage.data.checkerboard

chelsea
-------

.. autofunction:: skimage.data.chelsea

clock
-----

.. autofunction:: skimage.data.clock

coffee
------

.. autofunction:: skimage.data.coffee

coins
-----

.. autofunction:: skimage.data.coins

horse
-----

.. autofunction:: skimage.data.horse

hubble_deep_field
-----------------

.. autofunction:: skimage.data.hubble_deep_field

immunohistochemistry
--------------------

.. autofunction:: skimage.data.immunohistochemistry

lfw_subset
----------

.. autofunction:: skimage.data.lfw_subset

logo
----

.. autofunction:: skimage.data.logo

moon
----

.. autofunction:: skimage.data.moon

page
----

.. autofunction:: skimage.data.page

text
----

.. autofunction:: skimage.data.text

rocket
------

.. autofunction:: skimage.data.rocket

stereo_motorcycle
-----------------

.. autofunction:: skimage.data.stereo_motorcycle

