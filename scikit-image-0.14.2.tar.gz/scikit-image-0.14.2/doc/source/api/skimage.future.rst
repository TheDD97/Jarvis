.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`future`
=====================
.. automodule:: skimage.future

.. currentmodule:: skimage.future
.. autosummary::

   skimage.future.manual_lasso_segmentation
   skimage.future.manual_polygon_segmentation


    skimage.future.graph

manual_lasso_segmentation
-------------------------

.. autofunction:: skimage.future.manual_lasso_segmentation

manual_polygon_segmentation
---------------------------

.. autofunction:: skimage.future.manual_polygon_segmentation

