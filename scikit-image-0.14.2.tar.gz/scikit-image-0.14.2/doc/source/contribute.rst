.. toctree:: 
   :hidden: 
 
   gitwash/index 
   gsoc2011 
   cell_profiler 

.. include:: ../../CONTRIBUTING.txt
