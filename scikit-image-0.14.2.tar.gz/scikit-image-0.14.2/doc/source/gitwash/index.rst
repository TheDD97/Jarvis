.. _using-git:

Working with *scikit-image* source code
================================================

Contents:

.. toctree::
   :maxdepth: 2

   git_intro
   git_install
   following_latest
   patching
   git_development
   git_resources


