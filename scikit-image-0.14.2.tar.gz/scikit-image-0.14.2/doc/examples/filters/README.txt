Filtering and restoration
-------------------------
